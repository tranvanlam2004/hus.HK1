# BÀI 1: KHÔI PHỤC MASKED TOKEN
1. Mô hình có dự đoán đúng từ “capital” không?

Có. Mô hình đã lựa chọn đúng từ “capital” với độ tin cậy rất cao (xấp xỉ 99%).

Kết quả này cho thấy BERT nắm bắt tốt mối liên hệ ngữ nghĩa giữa “Hanoi” và cụm “capital of Vietnam”.

2. Vì sao mô hình Encoder-only như BERT phù hợp cho tác vụ này?

BERT sử dụng cơ chế tự chú ý hai chiều (bidirectional), cho phép mô hình quan sát đồng thời cả ngữ cảnh trước và sau vị trí [MASK].

Trong câu “Hanoi is the [MASK] of Vietnam”, mô hình dùng trọn vẹn thông tin từ cả hai phía để dự đoán chính xác.

BERT được pre-train bằng Masked Language Modeling, nên đặc biệt giỏi trong việc đoán các token bị che khuất.

Mô hình Decoder-only (như GPT) chỉ nhìn một chiều (từ trái sang phải), nên không khai thác được bối cảnh phía sau [MASK].

# BÀI 2: DỰ ĐOÁN TỪ TIẾP THEO
1. Kết quả sinh có hợp lý hay không?

Văn bản được GPT-2 sinh ra thường khá tự nhiên về mặt cú pháp và tương đối liền mạch.

Tuy nhiên thông tin đôi khi không hoàn toàn chính xác về mặt thực tế, vì mô hình ưu tiên sự trôi chảy hơn là độ chính xác tuyệt đối.

2. Lý do mô hình Decoder-only như GPT phù hợp với tác vụ này

GPT hoạt động dựa trên Self-Attention một chiều (causal), chỉ sử dụng các token đã xuất hiện để dự đoán token kế tiếp.

Mục tiêu huấn luyện chính là Next Token Prediction, trùng khớp với bài toán sinh văn bản.

Quá trình sinh văn bản của GPT là tự hồi quy (autoregressive): tạo token mới dựa trên chuỗi đã sinh.

Ngược lại, mô hình Encoder-only như BERT được thiết kế cho nhiệm vụ hiểu ngữ cảnh, không tối ưu cho việc tạo văn bản liên tục.

# BÀI 3: VECTOR BIỂU DIỄN CÂU
1. Kích thước vector biểu diễn và liên hệ với tham số của BERT

Kích thước vector tương ứng với tham số hidden_size của BERT-base.

Từ kết quả last_hidden_state.shape = [1, 8, 768], mỗi token trong câu được biểu diễn bằng vector 768 chiều.

2. Vì sao cần sử dụng attention_mask khi thực hiện Mean Pooling?

Khi xử lý nhiều câu có độ dài khác nhau, tokenizer sẽ thêm padding vào những câu ngắn hơn.

Các token padding không mang ý nghĩa ngữ nghĩa, nên nếu tính vào trung bình sẽ làm sai lệch vector biểu diễn.

attention_mask giúp ta loại padding ra khỏi phép tính Mean Pooling, đảm bảo vector thu được phản ánh đúng nội dung thực tế của câu.